package addon;

import java.time.LocalDate;
import java.time.Month;
import java.time.MonthDay;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

public class HurricaneSeasonQuery implements TemporalQuery<Boolean> {

    /*
     * (non-Javadoc)
     *
     * @see java.time.temporal.TemporalQuery#queryFrom(java.time.temporal.
     * TemporalAccessor)
     */
    @Override
    public Boolean queryFrom(TemporalAccessor temporal) {

        LocalDate date = LocalDate.from(temporal);

        MonthDay juneFirst = MonthDay.of(Month.JUNE.getValue(), 1);
        MonthDay novemberThirty = MonthDay.of(Month.NOVEMBER.getValue(), 30);

        if (date.isAfter(juneFirst.atYear(date.getYear()))
                && date.isBefore(novemberThirty.atYear(date.getYear()))) {
            return true;
        } else {
            return false;
        }
    }
}