package addon;
import java.time.LocalTime;
import java.time.temporal.TemporalQuery;

public class QueryExample2 {

    public static void main (String... args) {
        LocalTime t = LocalTime.of(20, 10, 20, 5000);
        Boolean b = t.query(WorkingHoursQuery);
        System.out.printf("Is %s working time: %s%n", t, b);

        t = LocalTime.of(15, 10, 20);
        b = t.query(WorkingHoursQuery);
        System.out.printf("Is %s working time: %s%n", t, b);

    }

    private static final TemporalQuery<Boolean> WorkingHoursQuery =
              temporal -> {
                  LocalTime t = LocalTime.from(temporal);
                  return t.compareTo(LocalTime.of(9, 0)) >= 0 &&
                            t.compareTo(LocalTime.of(17, 0)) < 0;
              };
} 