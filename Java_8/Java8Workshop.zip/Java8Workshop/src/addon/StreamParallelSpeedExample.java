package addon;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

// https://dzone.com/articles/should-i-parallalise-streams
// https://www.youtube.com/watch?v=NsDE7E8sIdQ
public class StreamParallelSpeedExample
{
    public static void main(String[] args)
    {
        for (int maxSize : new int[] {1_000, 10_000, 100_000, 1_000_000, 10_000_000, 100_000_000} )
        {       
            System.out.println("==============================");
            System.out.println("MEASURING " + maxSize);
            
            List<Integer> numberList = new ArrayList<>();
            for(int i = 1; i <= maxSize;i++) 
                numberList.add(i);
    
            /*
            performAction(numberList.stream(),"sequential");
            performAction(numberList.parallelStream() ,"parallel");
            */
            /*
            performActionSimple(numberList.stream(), "sequential");
            performActionSimple(numberList.parallelStream() ,"parallel");
            */
            performActionComplex(numberList.stream(),"sequential");
            performActionComplex(numberList.parallelStream() ,"parallel");
        }
        
        System.out.println("==============================");
        System.out.println("=======FINISH=================");
        System.out.println("==============================");
    }

    static List<Integer> performAction(Stream<Integer> numberStream, String info)
    {
        long start = System.nanoTime();
        
        List<Integer> result = numberStream.filter(i -> i % 2 == 0).
                        filter(i -> i % 12 == 0).
                        map(i-> i / 2).
                        filter(i -> i % 24 == 0).
                        map(i-> i * i).
                        collect(Collectors.toList());

        long end = System.nanoTime();
        System.out.println(info + " took " + TimeUnit.NANOSECONDS.toMillis(end-start) + " ms");
        return result;
    }
    
    static long performActionSimple(Stream<Integer> numberStream, String info)
    {
        long start = System.nanoTime();
        
        long result = numberStream.map(i-> i * 2).map(i-> i /2).count();

        long end = System.nanoTime();
        System.out.println(info + ": result " + result + " took " + TimeUnit.NANOSECONDS.toMillis(end-start) + " ms");
        return result;
    }
    
    static List<Integer> performActionComplex(Stream<Integer> numberStream, String info)
    {
        long start = System.nanoTime();
        
        List<Integer> result = numberStream.filter(i -> isPrime(i)).
//                        map(i-> i * i).
                        collect(Collectors.toList());

        long end = System.nanoTime();
        System.out.println(info + " took " + TimeUnit.NANOSECONDS.toMillis(end-start) + " ms");
        return result;
    }
    
    static boolean isPrime(int value)
    {
        if (value <= 1) return false;
        
        return !IntStream.rangeClosed(2, value/2).anyMatch(x -> value % x == 0);
    }
}
