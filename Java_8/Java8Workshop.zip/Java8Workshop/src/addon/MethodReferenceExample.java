package addon;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class MethodReferenceExample
{
    public static void main(String[] args)
    {
        List<String> names = Arrays.asList("Tim", "Tom", "Mike", "Thomas");

        Comparator<String> lexiSort = (str1, str2) -> str1.compareTo(str2);
        Comparator<String> lexiSortShorter = String::compareTo;

        names.sort(lexiSort);
        System.out.println(names);

        // geht nicht, da wir ja eine Referenz auf einen Comparator benötigen
        // names.sort(String::compare);

        // referenziert die Vergleichsmethode des Comparator
        names.sort(lexiSortShorter::compare);

        // ------------------------------------------------------------------
        Consumer<String> con1 = str -> System.out.println(str);
        Consumer<String> con2 = System.out::println;

        // ------------------------------------------------------------------
        List<Order> orders = Arrays.asList(new Order(5), new Order(7), new Order(24));

        // "lambda expression => explicit this"
        int sum = calculatValues(orders, order -> order.calculateValue());
        System.out.println("Sum is: " + sum);

        // "method reference => implicit this"
        sum = calculatValues(orders, Order::calculateValue);
        System.out.println("Sum is: " + sum);
    }

    private static int calculatValues(List<Order> orders, Function<Order, Integer> calc)
    {
        int sum = 0;

        for (Order order : orders)
            sum += calc.apply(order);

        return sum;
    }

    static class Order
    {

        final int value;

        public Order(final int value)
        {
            this.value = value;
        }

        public int calculateValue()
        {
            return value;
        }
        
        public static int always10()
        {
            return 10;
        }
    }
}
