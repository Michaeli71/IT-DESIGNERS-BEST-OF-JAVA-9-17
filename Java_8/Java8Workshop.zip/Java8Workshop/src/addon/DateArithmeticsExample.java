package addon;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

public class DateArithmeticsExample
{
    public static void main(String[] args)
    {
        System.out.println(Year.isLeap(2020));
        System.out.println(LocalDate.of(2020, 2, 29).minusYears(1));
        System.out.println(LocalDate.of(2020, 2, 28).minusYears(1));
        
        //System.out.println(LocalDate.of(2019, 2, 31));
        System.out.println(LocalDate.of(2020, 2, 28).plusDays(3));
        
        
        LocalDate someDay = LocalDate.of(1995,  2,  14);
        LocalDate someDay2 = LocalDate.of(1995, 4,  21);
        System.out.println("Day dif:" + daysBetween(someDay, someDay2));
        System.out.println("Month diff: " + monthBetween(someDay, someDay2));
        
        //System.out.println(daysBetween(someDay2, someDay));
        
        ZonedDateTime zdt = ZonedDateTime.now();
        LocalDateTime ldt = zdt.toLocalDateTime().minusDays(2);
        ZonedDateTime zdt2 = ZonedDateTime.of(ldt, ZoneId.of("Europe/Zurich"));

        System.out.println("ZDT day diff: "  + daysBetweenZDT(zdt, zdt2));
    }
    
    static int daysBetween(LocalDate date1, LocalDate date2)
    {
        return date1.until(date2).getDays();
    }
    
    static int monthBetween(LocalDate date1, LocalDate date2)
    {
        return date1.until(date2).getMonths();
    }
    
    static long daysBetweenZDT(ZonedDateTime zdt1, ZonedDateTime zdt2)
    {
        return zdt1.until(zdt2, ChronoUnit.DAYS);
    }
}
