package addon;

import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Comparator;

public class Snippet
{
    ActionListener actionListener = (event) -> System.out.println(event);

    public static void main(String[] args)
    {
        String[] names = { "Michael", "Otto", "Tim", "Peter" };

        Arrays.sort(names, (str1, str2) -> Integer.compare(str1.length(), str2.length()));
        System.out.println(Arrays.toString(names));

        Comparator<? super String> byLength = (str1, str2) -> Integer.compare(str1.length(), str2.length());
        Arrays.sort(names, byLength);
        System.out.println(Arrays.toString(names));

        MyFirstFunctional identity = str -> str;
        MyFirstFunctional toUpper = str -> str.toUpperCase();
        MyFirstFunctional toLower = str -> str.toLowerCase();

        MyFirstFunctional identity2 = new MyFirstFunctional()
        {
            @Override
            public String verySepcialOperation(String str)
            {
                return str;
            }
        };

        MySecondFunctional combiner = (str1, str2) -> str1 + str2;

        MySecondFunctional combiner2 = (String str1, final String str2) -> {
            str1 = str1 + str2;
            return str1;
        };

        int i = 1;
        String name = "Peter";
        //Person peter = new Person("Peter");
        // Beschränkung und Vereinfachung Analyse JVM/Compiler
        // ++i;
        doSomething(() -> {
            // Illegal: ++i;
            System.out.println("i: " + i + " name length: " + name.length());
        });
        // Illegal: ++i;  
        //++i;

        // ÄNDERUNGEN AN I, name
        //name = null;
        //peter.name = "PETRA";
        //peter.name = null;
        
    }

    private static void doSomething(Runnable action)
    {
        // ... längere Aktioen
        
        action.run();
    }

    @FunctionalInterface
    interface MyFirstFunctional
    {
        abstract String verySepcialOperation(String str);
        //abstract String secondOp(String str, String other);        
        //abstract String secondOp(String str);        
    }

    @FunctionalInterface
    interface MySecondFunctional
    {
        abstract String secondOp(String str, String other);
    }

}
