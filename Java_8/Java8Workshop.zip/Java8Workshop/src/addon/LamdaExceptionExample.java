package addon;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class LamdaExceptionExample
{
    public static void main(String[] args)
    {
        doAction(() -> System.out.println("ACTION"));

        // Aufrufe mit Exception => try / catch
        String path = "/some/path/";
        Path filePath = Path.of(path);
        try
        {
            Files.readAllLines(filePath);
        }
        catch (IOException ioe)
        {
            handleException(ioe);
        }

        // Aber was machen wir mit Exception in Lambda?
        // Da klappt es mit einem try-catch nicht: WIeso?
        doAction(() -> {
            String path2 = "/some/path/";
            Path filePath2 = Path.of(path2);
            try
            {
                Files.readAllLines(filePath2);
            }
            catch (IOException ioe)
            {
                // handleException(ioe);
                throw new IllegalStateException(ioe);
            }
        });
    }

    private static void handleException(IOException ioe)
    {
        // TODO Auto-generated method stub
    }

    static void doAction(Runnable action)
    {
        action.run();
    }

    /*
    static boolean performFileIO(String path) throws IOException
    {
        Path filePath = Path.of(path);
        
        Files.readAllLines(filePath);
    }
    */
}
