package addon;

import java.util.function.Predicate;
import java.util.stream.Stream;

public class LambdaDebug {

    public static void main(String[] args) {
        // Debugging
        Stream<String> names = Stream.of("Anne", "Peter", "John", "Mike", "Tim", "Mic", "Moni", "ABCDE");

        /*
        Predicate<String> strStartsWithM = str -> str.startsWith("M");
        Predicate<String> strLength4_ = str -> str.length() >= 4;
        Predicate<String> combi = strStartsWithM.or(strLength4_);
*/

        names.
            peek(name -> System.out.println("Before: " +name)).
            filter(CommonPredicates.strStartsWithM).
            peek(name -> System.out.println("After M: " +name)).
            filter(str -> str.length() >= 4).
            peek(name -> System.out.println("After 4: " +name)).
            forEach(System.out::println);
    }
}

class CommonPredicates
{
    public static Predicate<String> strStartsWithM = str -> str.startsWith("M");
    public static Predicate<String> strLength4_ = str -> str.length() >= 4;
    public static Predicate<String> combi = strStartsWithM.or(strLength4_);

    Predicate<Integer> isInRange = i -> i >= 10 && i < 70;
    Predicate<Integer> isInRange2 = isInRange(10, 70);
    Predicate<Integer> isInRange3 = isInRange(10, 500);

    public Predicate<Integer> isInRange(int lower, int upper)
    {
        return i -> i >= lower && i < upper;
    }
}
