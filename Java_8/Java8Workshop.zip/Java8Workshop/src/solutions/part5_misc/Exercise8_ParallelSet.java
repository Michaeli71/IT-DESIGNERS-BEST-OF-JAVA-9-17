package solutions.part5_misc;

import java.util.Arrays;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise8_ParallelSet {

	public static void main(final String[] args) 
	{
		final int[] original = new int[200];
		
		specialFill(original);
		printRange(original, 0, 20);
		printRange(original, 100, 120);
		printRange(original, 180, 200);		
		
		// JDK 8
		final int[] other = new int[200];		
		Arrays.parallelSetAll(other, i -> i % 100 );		
		
		printRange(other, 0, 20);
		printRange(other, 100, 120);
		printRange(other, 180, 200);
	}

	private static void specialFill(final int[] original) 
	{
		for (int j=0; j < original.length / 100; j++)
		{
			for (int i=0; i < 100; i++)
			{
				original[j * 100 + i] = i;
			}
		}
	}
	
	private static void printRange(final int[] original, final int start, final int end) 
	{
		for (int i=start; i < end; i++)
		{
			System.out.print(original[i] + " ");
		}
		System.out.println();
	}
}
