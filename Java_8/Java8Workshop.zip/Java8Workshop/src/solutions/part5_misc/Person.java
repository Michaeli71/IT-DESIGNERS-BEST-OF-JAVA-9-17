package solutions.part5_misc;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
class Person 
{
    final String name;
    final int age;

    public Person(final String name, final int age) 
    {
        this.name = name;
        this.age = age;
    }

    public String getName() 
    {
        return name;
    }

    public int getAge() 
    {
        return age;
    }

    public boolean isAdult() 
    {
        return getAge() >= 18;
    }
        
    public String toString()
    {
        return name + " is " + age + "years old";
    }
}