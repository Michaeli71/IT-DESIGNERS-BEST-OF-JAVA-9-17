package solutions.part5_misc;

import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class Exercise6_FirstCompletableFutureExample 
{
	public static void main(String[] args) throws Exception {

		// Schritt 1: Aufwendige Berechnung, hier nur Rückgabe von einem String final
		Supplier<String> longRunningAction = () ->
		{
			System.out.println("Current thread: " + Thread.currentThread());
			return "101";
		};
		
		final CompletableFuture<String> step1 = CompletableFuture.supplyAsync(longRunningAction);
		
		// Schritt 2: Konvertierung, hier nur Abbildung von String auf Integer 
		final Function<String, Integer> complexConverter = Integer::parseInt;
		final CompletableFuture<Integer> step2 = step1.thenApply(complexConverter);
		
		// Schritt 3: Konvertierung, hier nur Multiplikation mit .75
		final Function<Integer, Double> complexCalculation = value -> .75 * value;
		final CompletableFuture<Double> step3 = step2.thenApply(complexCalculation);
		
		// Explizites Auslesen per get() löst die Verarbeitung aus
		System.out.println(step3.get());
	}
}