package solutions.part5_misc;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise2_Optional_Usage
{
    public static void main(final String[] args)
    {
        final List<Person> persons = Arrays.asList(new Person("Tim", 44), 
                                                   new Person("Tom", 6), 
                                                   new Person("Mike", 28));        
        
        final Optional<Person> optOldestPerson = findOldestPerson(persons);
        System.out.println(optOldestPerson);
    }

    private static Optional<Person> findOldestPerson(final List<Person> persons)
    {        
        // final Comparator<Person> byAge = (person1, person2) -> Integer.compare(person1.getAge(), person2.getAge());
       
        final Comparator<Person> byAge = Comparator.comparing(Person::getAge);
        
        return persons.stream().max(byAge);
    }
}
