package solutions.part5_misc;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class Exercise5_Optional_SafeResolve
{
    public static void main(final String[] args) 
    {
        /*
         * final Computer computer = new Computer(); final String version =
         * computer.getGraphicscard().getFimrware().getVersion();
         * System.out.println(version);
         *
         * 
        final Computer computer22 = new MalfuncitioningComputer(); // NPE final String
        String version22 = computer22.getGraphicscard().getFimrware().getVersion();
        System.out.println(version22);
         */

        final Computer computer = new Computer();
        final Optional<String> version = safeResolve(  () -> computer.getGraphicscard().getFimrware().getVersion()  );
        System.out.println(version);

        final Computer computer2 = new MalfuncitioningComputer();
        final Optional<String> version2 = safeResolve(() -> computer2.getGraphicscard().getFimrware().getVersion());
        System.out.println(version2);
    }

    public static <T> Optional<T> safeResolve(final Supplier<T> resolver) 
    {
        try 
        {
            final T result = resolver.get();
            return Optional.ofNullable(result);
        } 
        catch (final NullPointerException npe) 
        {
            return Optional.empty();
        }
    }
}

class Computer {

    public Graphicscard getGraphicscard() {
        return new Graphicscard();
    }
}

class MalfuncitioningComputer extends Computer {

    @Override
    public Graphicscard getGraphicscard() {
        return null;
    }
}

class Graphicscard {

    public Firmware getFimrware() {
        return new Firmware();
    }

}

class Firmware {

    public String getVersion() {
        return "V1.2.3";
    }
}