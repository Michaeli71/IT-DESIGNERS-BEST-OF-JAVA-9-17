package solutions.part2_bulk_operations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise6_RemoveAndReplaceAll
{
    public static void main(final String[] args)
    {
        final List<String> names = new ArrayList<>(Arrays.asList("Jan", "Michael  ", "", " Tim ", 
                                                                 null, " Tom ", " Marius "));

        // null raus
        final Predicate<String> isNull = str -> str == null;
        names.removeIf(isNull);

        // Leerzeichen entfernen
        final UnaryOperator<String> trimmer = String::trim;
        names.replaceAll(trimmer);
        
        // Leerstrings raus
        //final Predicate<String> isEmpty = String::isEmpty;
        final Predicate<String> isShort = str -> str.length() < 4;
        names.removeIf(isShort);

        System.out.println(names);
    }
}