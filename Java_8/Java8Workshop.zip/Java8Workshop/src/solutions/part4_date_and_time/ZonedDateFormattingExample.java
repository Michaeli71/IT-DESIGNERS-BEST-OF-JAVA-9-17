package solutions.part4_date_and_time;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class ZonedDateFormattingExample 
{
	public static void main(String[] args) 
	{	
		final LocalDateTime ldt = LocalDateTime.of(2016, 7, 14, 5, 25, 45);
		final String pattern = "'Datum:' dd.MM.yyyy ' / Uhrzeit:' HH:mm";
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		System.out.println("formattedDate " + formatter.format(ldt)); 
	
		final String zonedDateTime = "2007-12-03T10:15:30+01:00[Europe/Paris]";
		final ZonedDateTime zdt = ZonedDateTime.parse(zonedDateTime);
		System.out.print(zdt + " as LocalDateTime " + zdt.toLocalDateTime());
		System.out.println(" / ZoneId " + zdt.getZone());
		System.out.println(" / ZoneOffset " + zdt.getOffset());
	}
}
