package solutions.part4_date_and_time;

import java.time.LocalDate;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class LengthOfMonth 
{
	public static void main(final String[] args) 
	{
		final LocalDate february_2_2012 = LocalDate.of(2012, 2, 2);
		final LocalDate february_2_2014 = LocalDate.of(2014, 2, 2);
		final LocalDate april_4_2014 = LocalDate.of(2014, 4, 4);
		final LocalDate may_5_2014 = LocalDate.of(2014, 5, 5);
		
		// a)
		System.out.println(february_2_2012.plusMonths(1));
		System.out.println(february_2_2014.plusMonths(1));
		System.out.println(april_4_2014.plusMonths(1));
		System.out.println(may_5_2014.plusMonths(1));
		
		// b)
		System.out.println(february_2_2012.plusDays(28)); // 29 benätigt
		System.out.println(february_2_2014.plusDays(28));
		System.out.println(april_4_2014.plusDays(30));
		System.out.println(may_5_2014.plusDays(31));
	}
}
