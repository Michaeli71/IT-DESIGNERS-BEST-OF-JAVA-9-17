package solutions.part3_streams_and_filter_map_reduce;

import java.util.stream.IntStream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise6c_InfiniteStreamSurprises
{
    public static void main(String[] args)
    {
        IntStream.iterate(0, i -> i + 1).
                  boxed().
                  // sorted()
                  limit(10).
                  sorted().
                  map(e -> "" + e).
                  forEach(System.out::println);
    }
}
