package solutions.part3_streams_and_filter_map_reduce;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise12_MapComputeIfPresentExample
{
    public static void main(String[] args)
    {
        final Map<String, Integer> wordCounts = new LinkedHashMap<>();

        final String shortStory = "Diese Geschichte IST kurz und handelt von TIM. TIM wohnt in Kiel. TIM arbeitet in "
                                  + " Bremen. TIM IST während der Arbeitswoche dort. TIM fährt donnerstags nach Hause.";

        // Einkommentieren, um spezielle Worte zu zählen
//        wordCounts.put("TIM", 0);
//        wordCounts.put("IST", 0);
//        wordCounts.put("in", 0);

        // for (final String word : shortStory.split(" "))
        for (final String word : shortStory.split("( |\\.)"))
        {
            // Histogramm, putIfAbsent auskommentieren, um spezielle Worte zu zählen
            wordCounts.putIfAbsent(word, 0);
            wordCounts.computeIfPresent(word, (key, value) -> value + 1);
        }
        System.out.println(wordCounts);
    }    
}
