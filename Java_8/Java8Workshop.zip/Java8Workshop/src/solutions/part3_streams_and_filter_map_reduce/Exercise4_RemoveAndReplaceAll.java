package solutions.part3_streams_and_filter_map_reduce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise4_RemoveAndReplaceAll
{
    public static void main(final String[] args)
    {
        final List<String> names = new ArrayList<>(Arrays.asList("Jan", "Michael  ", "", " Tim ", 
                                                                 null, " Tom ", " Marius "));

        // null raus
        final Predicate<String> isNull = str -> str == null;
        // Leerzeichen entfernen
        final UnaryOperator<String> trimmer = String::trim;
        // kurze Worte
        final Predicate<String> isShort = str -> str.length() < 4;

        final List<String> result = names.stream().filter(isNull.negate()).
                                                   map(trimmer).
                                                   filter(isShort.negate()).
                                                   collect(Collectors.toList());
                                                   
        System.out.println(result);
    }
}