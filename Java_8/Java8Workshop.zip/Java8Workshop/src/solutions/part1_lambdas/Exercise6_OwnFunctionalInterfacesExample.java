package solutions.part1_lambdas;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise6_OwnFunctionalInterfacesExample
{
    public static void main(final String[] args)
    {
        final StringToIntConverter stringToLength = str -> str.length();
        final StringToStringConverter stringToTrimmedString = str -> str.trim();
        final StringToStringConverter stringToUpperCaseString = String::toUpperCase;

        System.out.println("stringToLength('Java') => " + stringToLength.convert("Java"));
        System.out.println("stringToTrimmedString('  Michael  ') => '" + stringToTrimmedString.convert("  Michael  ")
                           + "'");
        System.out.println("stringToUpperCaseString('Hands On') => " + stringToUpperCaseString.convert("Hands On"));
    }

    // Bildet Objekte von Typ String auf int ab.
    @FunctionalInterface
    public interface StringToIntConverter
    {
        int convert(final String input);
    }

    // StringToStringMapper: Bildet Objekte von Typ String auf String.
    @FunctionalInterface
    public interface StringToStringConverter
    {
        String convert(final String input);
    }
}