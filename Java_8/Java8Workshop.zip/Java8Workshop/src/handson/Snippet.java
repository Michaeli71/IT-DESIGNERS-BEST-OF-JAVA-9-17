package handson;

import java.io.FileFilter;
import java.util.Comparator;

public class Snippet
{
    public static void main(String[] args)
    {
        final FileFilter directoryFilter = pathname -> pathname.isDirectory();

        final FileFilter pdfFileFilter = pathname -> (pathname.isFile() && pathname.getName().toLowerCase().endsWith(".pdf"));
        
        
        
        Comparator<String> byLength = (str1, str2) -> Integer.compare(str1.length(), str2.length());
        
        Demo myDemo = (s1, val, s2) -> System.out.println(s1 + " " + val + " " + s2);
        myDemo.doSomething("HELLO", 2, "WORLD");
    }
    
    @FunctionalInterface
    interface Demo
    {
        void doSomething(String str, int value, String info);
    }
}
