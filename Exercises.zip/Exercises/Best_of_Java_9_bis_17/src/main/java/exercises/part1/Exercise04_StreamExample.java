package exercises.part1;

import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise04_StreamExample 
{	
	public static void main(String[] args) 
	{
		final Stream<String> values1 = Stream.of("a", "b", "c", "", "e", "f"); 
		final Stream<Integer> values2 = Stream.of(1, 2, 3, 11, 22, 33, 7, 10);

		// TODO
	}
}
