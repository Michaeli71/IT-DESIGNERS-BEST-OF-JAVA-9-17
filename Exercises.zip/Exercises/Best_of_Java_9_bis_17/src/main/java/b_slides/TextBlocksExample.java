package b_slides;

public class TextBlocksExample {

	public static void main(String[] args) {

		String jsonObj = """
						{
						    name: "Mike",
					        birthday: "1971-02-07",
						    comment: "Text blocks are nice!"
						}
				     """;

		System.out.println(jsonObj);
		
		String text = """
				      This is a string splitted in several smaller \
				      jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj \
				      jjjjjjjjjjjjjjjjjjjjjjjj \
				      jjjjjjjjjjjj strings""";    

		System.out.println(text);
		System.out.println(text.getClass());

	}

}
