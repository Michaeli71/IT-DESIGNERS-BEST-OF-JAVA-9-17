package a_questions;

import java.util.ArrayList;

public class VarExample {

	public static void main(String[] args) {
		
		var names = new ArrayList<String>();
		names.add("Tim");
		//names.add(72);
		
		//List.of
	}

}
