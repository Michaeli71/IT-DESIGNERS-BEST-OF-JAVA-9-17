package a_questions;

import java.time.LocalDate;

public record SpecialPerson(String name, LocalDate birthday) {}
