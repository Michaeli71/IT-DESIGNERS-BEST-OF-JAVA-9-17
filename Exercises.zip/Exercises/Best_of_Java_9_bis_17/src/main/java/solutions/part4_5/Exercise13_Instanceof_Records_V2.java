package solutions.part4_5;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise13_Instanceof_Records_V2 
{
	// Verbesserung durch Einführen eines Basistyps und einer Methode calcArea() 
	interface BaseFigure
	{
		double calcArea();
	}
	
	record Square(double sideLength) implements BaseFigure {

		@Override
		public double calcArea() {
			return sideLength * sideLength;
		}
	}

	record Circle(double radius) implements BaseFigure 
	{
		@Override
		public double calcArea() 
		{
			return radius * radius * Math.PI;
		}
	}
	
	public double computeArea(final Object figure) 
	{
		if (figure instanceof Square square) 
		{
			return square.calcArea();
		} 
		else if (figure instanceof Circle circle) 
		{
			return circle.calcArea();
		}
		throw new IllegalArgumentException("figure is not a recognized figure");
	}	
}
