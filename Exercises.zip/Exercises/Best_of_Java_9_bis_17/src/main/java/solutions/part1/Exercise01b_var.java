package solutions.part1;

import java.util.Map;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise01b_var 
{
	public static void main(String[] args) 
	{
		funWithVar();
	}

	static void funWithVar()
	{
		Map<String, Integer> personsAndAges = Map.of("Tim", 47, "Tom", 7, "Mike", 47);
		var personsAndAges2 = Map.of("Tim", 47, "Tom", 7, "Mike", 47);
	}

}
