package solutions.part3;

import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
// HINWEIS AUFGABENSTELLUNG: Verkürze second bei jedem weiteren Vergleich 
public class Exercise03_Arrays 
{
	public static void main(final String[] args) 
	{		
		final byte[] string1 = "ABC-DEF-GHI".getBytes();
		final byte[]  string2 = "DEF".getBytes();
		System.out.println(Arrays.compare(string1, string2));
		System.out.println(Arrays.compare(string1, 4, 7, 
		                                  string2, 0, 3));
		System.out.println(Arrays.compare(string1, 8, 11, 
                                          string2, 0, 3));
		
		
		final byte[] first =  "ABCDEFGHIJK".getBytes();
		final byte[] second = "XYZABCDEXYZ".getBytes();
		
		System.out.println("compare: " + Arrays.compare(first, second));
		
		for (int i=0; i < Math.min(first.length, second.length); i++)
		{
			final int maxLength = Math.min(first.length, second.length);

			System.out.println("Comparing: " + new String(Arrays.copyOfRange(first, i, maxLength)) + " and " +
					new String(Arrays.copyOfRange(second, i, maxLength)));

			System.out.println("compare from " + i + " to " + (maxLength) + " - result: " + 
					          Arrays.compare(first, i, maxLength, second, i, maxLength));
		}
	}
}
